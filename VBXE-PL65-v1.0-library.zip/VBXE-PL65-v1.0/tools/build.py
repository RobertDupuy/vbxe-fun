#!/usr/bin/env python3
"""Build PL/65 programs with the original Noahsoft compiler."""
from pathlib import Path
import argparse,json,re
from pl65_host import Compiler
ROOT=Path(__file__).resolve().parents[1]

def compile_source(compiler,source,build):
    build.mkdir(parents=True,exist_ok=True)
    for folder in ['lib','src','examples']:
        for p in (ROOT/folder).glob('*'):
            if p.suffix.upper() in ('.LIB','.P65'):
                (build/p.name.upper()).write_bytes(p.read_bytes().replace(b'\r\n',b'\n').replace(b'\n',b'\x9b'))
    c=Compiler(compiler,build,f'1D:{source}\nD:OUT.XEX\nD:OUT.LST\nD:OUT.ERR\na5D:OUT.XRF\n')
    log=c.run();(build/'compiler-log.txt').write_text(log)
    err=(build/'OUT.ERR').read_bytes().replace(b'\x9b',b'\n').decode('latin1')
    if '\n0 errors.' not in err:raise RuntimeError(err)
    syms={}
    for line in (build/'OUT.XRF').read_bytes().decode('latin1').split('\x9b'):
        m=re.match(r'\s*\d+\s+([0-9A-F]+)\s+[0-9A-F]+\s+(\S+)',line)
        if m:syms[m[2]]=int(m[1],16)
    (build/'symbols.json').write_text(json.dumps(syms,indent=2))
    return (build/'OUT.XEX').read_bytes(),syms

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--compiler',required=True);ap.add_argument('--source',default='HELLOVB.P65');a=ap.parse_args()
    compiled,symbols=compile_source(a.compiler,a.source,ROOT/'build'/Path(a.source).stem.lower())
    out=ROOT/'build'/Path(a.source).with_suffix('.xex').name
    out.write_bytes(compiled)
    print(out,len(compiled),'bytes')
if __name__=='__main__':main()
