#!/usr/bin/env python3
"""Run Noahsoft PL65.COM with host-backed Atari CIO."""
from pathlib import Path
from collections import deque
import argparse, json, sys
from py65.devices.mpu6502 import MPU

class Compiler:
    def __init__(self, compiler, directory, keys):
        self.root=Path(directory); self.m=MPU(); self.mem=self.m.memory
        b=Path(compiler).read_bytes(); i=0
        while i<len(b):
            if b[i:i+2]==b'\xff\xff': i+=2; continue
            a=int.from_bytes(b[i:i+2],'little'); e=int.from_bytes(b[i+2:i+4],'little'); i+=4
            self.mem[a:e+1]=b[i:i+e-a+1]; i+=e-a+1
        self.m.pc=self.word(0x2e0)
        self.setword(0x2e5,0xbc00); self.setword(0x2e7,0x2000)
        self.mem[0x6a]=0xc0; self.mem[0x11]=0xff; self.mem[0x2fc]=0xff
        self.setword(0x58,0xbc40); self.setword(0x230,0xbc20)
        self.setword(0xe424,0xe0ff)
        self.keys=deque(keys.replace('\n','\x9b').encode('latin1'))
        self.files={}; self.screen=bytearray(); self.calls=0
    def word(self,a): return self.mem[a]+256*self.mem[a+1]
    def setword(self,a,v): self.mem[a]=v&255; self.mem[a+1]=v>>8
    def rts(self): self.m.pc=(self.m.stPopWord()+1)&65535
    def status(self,s=1):
        self.m.y=s; self.m.p=(self.m.p&~0x82)|(s&0x80)|(2 if s==0 else 0)
        self.mem[0x343+self.m.x]=s; self.mem[0x303]=s
    def cio(self):
        self.calls+=1; m=self.mem; x=self.m.x; c=0x340+x
        cmd=m[c+2]; a=self.word(c+4); n=self.word(c+8); status=1
        if cmd==3:
            name=bytes(m[a:a+128]).split(b'\x9b')[0].split(b'\0')[0].decode('ascii',errors='replace')
            if ':' in name: device,name=name.split(':',1)
            else: device='D'
            if device.startswith('D'):
                name=name.strip(); p=self.root/name
                mode='rb' if m[c+10]==4 else ('ab' if m[c+10]==9 else 'wb')
                try: self.files[x]=p.open(mode)
                except FileNotFoundError: status=170
            else: self.files[x]=None
            m[c]=0 if status==1 else 255
        elif cmd==12:
            f=self.files.pop(x,None)
            if f:f.close()
            m[c]=255
        elif cmd in (5,7):
            f=self.files.get(x)
            if f:
                if cmd==5:
                    data=bytearray()
                    while len(data)<n:
                        b=f.read(1)
                        if not b:status=136;break
                        data+=b
                        if b==b'\x9b':break
                else:
                    data=f.read(n or 1)
                    if len(data)<(n or 1):status=136
            else:
                data=bytearray()
                while len(data)<(n or 1):
                    if not self.keys: raise EOFError('keyboard queue empty')
                    k=self.keys.popleft();data.append(k)
                    if cmd==5 and k==155:break
            if n:
                m[a:a+len(data)]=list(data);self.setword(c+8,len(data))
            if data:self.m.a=data[-1]
        elif cmd in (9,11):
            data=bytes(m[a:a+n]) if n else bytes([self.m.a])
            if cmd==9:
                data=data.split(b'\x9b')[0]+b'\x9b'
            f=self.files.get(x)
            if f: f.write(data)
            else:
                self.screen+=data
        elif cmd==13:pass
        else: raise RuntimeError(f'unsupported CIO {cmd} at {a:04x} size {n}')
        self.status(status); self.rts()
    def run(self,limit=150_000_000):
        try:
            for i in range(limit):
                if self.m.pc==0xe456:self.cio()
                elif self.m.pc==0xe100:
                    if not self.keys: raise EOFError('keyboard queue empty')
                    self.m.a=self.keys.popleft();self.status();self.rts()
                elif self.m.pc>=0xc000:raise RuntimeError(f'Unexpected OS entry {self.m.pc:04x}')
                elif self.mem[self.m.pc]==0:raise RuntimeError(f'BRK at {self.m.pc:04x}')
                else:self.m.step()
            raise RuntimeError('instruction limit')
        except EOFError:pass
        finally:
            for f in self.files.values():
                if f:f.close()
        return self.screen.decode('latin1').replace('\x9b','\n')

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('compiler');ap.add_argument('directory');ap.add_argument('source');a=ap.parse_args()
    c=Compiler(a.compiler,a.directory,'1D:'+a.source+'\nD:OUT.XEX\nD:OUT.LST\nD:OUT.ERR\n')
    try:print(c.run())
    except Exception:
        print(c.screen.decode('latin1').replace('\x9b','\n'));raise
