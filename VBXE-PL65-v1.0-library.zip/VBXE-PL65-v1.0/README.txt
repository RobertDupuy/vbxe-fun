VBXE FOR NOAHSOFT PL/65 v1.0

Reusable libraries for Atari XL/XE with VBXE FX 1.20+.
Disable BASIC. See docs/VBXE-API.txt for calls and memory ownership.

lib/       Core detection, VRAM, palettes, blitter, sprite and bitmap modules.
examples/  Bitmap and animated sprite programs.
atascii/   Copies with Atari line endings.
text/      Individual readable .txt copies.
SOURCE.txt Source and documentation in one file.
build/     Ready-to-run examples.
tools/     Original-compiler host and builder.

BUILD
Install Python 3 and py65. Obtain Noahsoft PL65.COM separately.
  python3 tools/build.py --compiler /path/to/PL65.COM --source HELLOVB.P65
  python3 tools/build.py --compiler /path/to/PL65.COM --source SPRITE.P65

For native Atari compilation, copy atascii/ to D: and use ORG $2100,
stack $2000, zero page $80, runtime and autorun enabled.

Project: Mark2006.
Noahsoft PL/65 runtime routines: Copyright (C) 1987 Noahsoft.
New library code, examples and tools: MIT license; see LICENSE.txt.
