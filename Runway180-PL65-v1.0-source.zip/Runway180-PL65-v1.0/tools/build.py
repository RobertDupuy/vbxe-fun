#!/usr/bin/env python3
"""Compile with Noahsoft PL/65 and package a standalone segmented XEX."""
from pathlib import Path
import argparse,json,re,struct,sys
from pl65_host import Compiler
ROOT=Path(__file__).resolve().parents[1]

def segments(data):
    i=0
    while i<len(data):
        if data[i:i+2]==b'\xff\xff':i+=2;continue
        a,b=struct.unpack_from('<HH',data,i);i+=4
        yield a,data[i:i+b-a+1];i+=b-a+1

def segment(a,b):return struct.pack('<HH',a,a+len(b)-1)+b

def compile_source(compiler,source,build):
    build.mkdir(parents=True,exist_ok=True)
    for folder in ['lib','src','examples']:
        for p in (ROOT/folder).glob('*'):
            if p.suffix.upper() in ('.LIB','.P65'):
                (build/p.name.upper()).write_bytes(p.read_bytes().replace(b'\r\n',b'\n').replace(b'\n',b'\x9b'))
    c=Compiler(compiler,build,f'1D:{source}\nD:OUT.XEX\nD:OUT.LST\nD:OUT.ERR\na5D:OUT.XRF\n')
    log=c.run();(build/'compiler-log.txt').write_text(log)
    err=(build/'OUT.ERR').read_bytes().replace(b'\x9b',b'\n').decode('latin1')
    if '\n0 errors.' not in err:raise RuntimeError(err)
    syms={}
    for line in (build/'OUT.XRF').read_bytes().decode('latin1').split('\x9b'):
        m=re.match(r'\s*\d+\s+([0-9A-F]+)\s+[0-9A-F]+\s+(\S+)',line)
        if m:syms[m[2]]=int(m[1],16)
    (build/'symbols.json').write_text(json.dumps(syms,indent=2))
    return (build/'OUT.XEX').read_bytes(),syms

def pack(compiled,symbols,assets):
    result=bytearray(b'\xff\xff');tail=bytearray()
    for a,b in segments(compiled):
        if a==0x2e0:tail+=segment(a,b)
        else:
            result+=segment(a,b)
    for address,data in assets:
        while data:
            offset=address&4095;chunk=data[:4096-offset];data=data[len(chunk):]
            result+=segment(0x600,struct.pack('<BHH',address//4096,len(chunk),offset))
            result+=segment(0x9000,chunk)
            result+=segment(0x2e2,struct.pack('<H',symbols['LoadAsset']))
            address+=len(chunk)
    result+=tail
    return bytes(result)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--compiler',required=True);ap.add_argument('--source',default='RUNWAY.P65');a=ap.parse_args()
    build=ROOT/'build'/Path(a.source).stem.lower()
    compiled,symbols=compile_source(a.compiler,a.source,build)
    if a.source=='RUNWAY.P65':
        packed=pack(compiled,symbols,[(0x200,(ROOT/'assets/VBPAL.BIN').read_bytes()),(0x1e00,(ROOT/'assets/SHEET.BIN').read_bytes()+bytes(320))])
        out=ROOT/'build/Runway180-PL65-v1.0.xex'
    else:packed=compiled;out=ROOT/'build'/Path(a.source).with_suffix('.xex').name
    out.write_bytes(packed)
    print(out, len(packed),'bytes',flush=True)
if __name__=='__main__':main()
