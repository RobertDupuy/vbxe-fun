RUNWAY 180 - VBXE / NOAHSOFT PL/65 v1.0

Requires a 64 KB Atari XL/XE and VBXE FX 1.20+. Disable BASIC.
Load build/Runway180-PL65-v1.0.xex. Graphics are included in the XEX.

CONTROLS
G, START or fire: start. I: instructions.
Left/right: accelerate/brake. Up/down: decrease/increase sink rate.
Fire or SPACE: lower gear; retract gear during a stall.
Land at speed 50-53, gear down, sink rate 1 or 2. Brake before the tower.
Controls repeat about every 0.6 seconds. Hold right to brake after landing.
Braking from 52 takes about 11 seconds; leave enough runway.
On the runway, speed above 60 plus fire gives a touch-and-go.
Five approaches. After a flight, fire/Y restarts; N returns to DOS.

V1.0
Flight now follows the TI version's independent sprite motion, control pace,
braking and wind rules. Wind is seeded at each approach. PAL and NTSC use
the same nominal game timing. TI coordinates are scaled to the VBXE artwork;
this is an adaptation, not an instruction-for-instruction TI emulation.

FILES
src/       Game, scenery and asset loader.
lib/       Reusable VBXE libraries.
examples/  Bitmap and animated sprite examples.
atascii/   Atari line-ending copies for native compilation.
text/      Individual .txt copies of source and documentation.
SOURCE.txt Source and documentation in one readable file.
docs/      VBXE API reference.
tools/     Compiler host and XEX packer.

BUILD
Install Python 3 and py65, then run:
  python3 tools/build.py --compiler /path/to/PL65.COM
Example:
  python3 tools/build.py --compiler /path/to/PL65.COM --source HELLOVB.P65
The host runs the original Noahsoft compiler and handles Atari CIO calls.
PL65.COM is required separately. Listings and logs go to build/.

For Atari compilation, copy atascii/ to D: and compile RUNWAY.P65 with
ORG $2100, stack $2000, zero page $80, runtime and autorun enabled.
The game needs the asset segments added by tools/build.py. Examples do not.

SOURCE NOTES
Motion uses 1/16-pixel TI units at nominal 60 Hz. SINK has a bias of 128;
SPEEDQ uses quarter-speed units. AIRDELAY, BRAKEDELAY and STALLDELAY set
control repeat intervals. Fire is edge-triggered; scores are integers.
CPU: $2000-$7FFF stack/code, $8000-$8FFF MEMAC, $9000-$9FFF loader,
$A000 screen, $A400 display list, $AC00-$AFFF player/missile graphics.
VRAM: $00000 XDL, $00200 palette, $00500/$00515 BCBs,
$01E00 sprite sheet, $10000 bitmap. See docs/VBXE-API.txt.

CREDITS
Original TI-99/4A game: James Dunn, COMPUTE!, October 1983.
TI Game Shelf version: Ray Kazmer revision, March 1989.
  https://tigameshelf.net/xb.htm
VBXE artwork: RobertDupuy/vbxe-fun.
Project: Mark2006.
Noahsoft PL/65 runtime routines: Copyright (C) 1987 Noahsoft.
PL/65 port, libraries and tools: MIT license; see LICENSE.txt.
